# KEYİF PARK — Kalıcı geliştirme kuyruğu

16 Eylül 2026. Sıra bağımlılıklara göre düzenlenmiştir. Süre tahmini veya aktif görev ilanı değildir. Her işin durumu: bekliyor / çalışıyor / doğrulandı / engelli. Yalnız kabul kanıtı bulunan iş doğrulandı olur.

## Yerel incelemede doğrulanan başlangıç

`../keyif-park/components/Site.tsx` ve `../keyif-park/lib/data.ts` okundu:

- Next.js sayfaları, ortak veri dizisi, menü, kategori filtresi, ad araması, detay iskeleti, dil seçici ve AR yön ayarı var.
- Veri dizisi dört DEMO ürün içeriyor; gerçek katalog uygulamaya bağlı değil.
- Marka geçici simge; onaylı logo arayüze uygulanmamış.
- A/B aynı bileşenin küçük farklılıkları; istenen iki ayrı tasarım tamamlanmamış.
- 12 dil etiketi var; ürün adları ve birçok metin TR/EN seçiminden geliyor. Tam 12 dil yok.
- Teklif formu yalnız JSON dosyası indiriyor; gerçek talep teslimi yok.
- E-katalog temsili kapak; gerçek belge bağlantısı yok.
- Yönetim, chatbot ve görsel arama bu incelenen uygulamada yok.
- Önceki test dosyaları mevcut; bu inceleme yeni test koşusu değildir. Bulut kataloğunun anlık durumu bu belgeyle doğrulanmış sayılmaz.

## İşler

| Kimlik | İş ve tamamlanma kanıtı | Bağımlılık | Durum |
|---|---|---|---|
| DEV-01 | Bulut geliştirme çalıştırıcısını doğrula: yetkilendirilmiş model erişimi, sınırlı görev, özel depo, log, süre/harcama sınırı, başarısızlık kaydı, sıradaki iş; gerçek örnek kod değişikliği ve test sonucu | Hesap erişimi | Bekliyor |
| DEV-02 | Proje ve bu belgeleri aynı sürüm kontrollü depoya taşı; gizli anahtarları dışarıda tut; mevcut uygulama derlemesini kaydet | Depo | Bekliyor |
| DEV-03 | Katalog çıktısına şema adaptörü: id/kod/seri/kategori/metin/ölçü/medya/belge/kaynak/doğrulama alanları; hatalı ve eksik kayıt raporu | Katalog örneği | Bekliyor |
| DEV-04 | Medya aktarımını uygulamaya bağla: orijinal saklama, optimize web türevleri, hatalı dosya yedeği, tekrar etmeyen import; iki gerçek üründe doğrula | DEV-03 | Bekliyor |
| DEV-05 | Onaylı marka dosyasını kullanıma hazır hale getir; renk/tipografi/boşluk/buton kuralları ve erişilebilir kontrast | Marka referansı | Bekliyor |
| DEV-06 | A ana sayfasını premium görsel yönle kodla; 390 ve 1440 ekran görüntüsü ve gezinme kanıtı | DEV-04,05 | Bekliyor |
| DEV-07 | B ana sayfasını seri/katalog keşfi odaklı ayrı yerleşimle kodla; A ile aynı ürün kaynağını kullandığını doğrula | DEV-04,05 | Bekliyor |
| DEV-08 | Kategori/seri gezinmesi, kod ve ad araması, filtre boş durumu, sayfalama; gerçek veriyle akış testi | DEV-03,04 | Bekliyor |
| DEV-09 | Ürün detayı: galeri, mevcut ölçüler, dokümanlar, benzer ürünler, teklif listesine ekleme; 404 testi | DEV-08 | Bekliyor |
| DEV-10 | Teklif listesi ve gerçek teslim formu; hata/başarı/istenmeyen gönderim koruması, gerçek alıcı doğrulaması | DEV-09, alıcı bilgisi | Bekliyor |
| DEV-11 | Gerçek e-katalog girişi, belge indirme ve mobil kullanım; kaynakta bulunmayan dokümanları işaretle | DEV-03,04 | Bekliyor |
| DEV-12 | Tam sözlük yapısı, 12 dil çevirileri ve içerik kapsam raporu; AR düzeni ve dil geçişi testi | DEV-06–11 | Bekliyor |
| DEV-13 | İçerik yönetimi: doğrulanmış sağlayıcı seçimi, ürün/belge güncelleme, yetki ve yedekleme örneği | DEV-03, hesap/maliyet | Bekliyor |
| DEV-14 | Chatbot ve arama entegrasyonu: doğrulanmış ürün yanıtları, bilinmeyen sorular, hizmet kesintisi, kullanım sınırları | DEV-03, sağlayıcı erişimi | Bekliyor |
| DEV-15 | Görsel arama örnek sorguları ve doğru ürüne ulaşma kontrolü; kalite sınırını ölç | DEV-04, sağlayıcı erişimi | Bekliyor |
| DEV-16 | Kurumsal/iletişim/gizlilik sayfaları; gerçek işletme bilgileri, boş referans sayfası; SEO metadata/sitemap | Doğru işletme bilgisi | Bekliyor |
| DEV-17 | Katalog tamlık uzlaştırması; başarısız kaynak listesi ve tekrar deneme; iki tasarımda aynı kayıt sayısı | DEV-03, tüm aktarım | Bekliyor |
| DEV-18 | Mobil/masaüstü, klavye, form, dil, kırık link/görsel, üretim derlemesi ve performans kontrolleri; rapor ve önizleme | DEV-06–17 | Bekliyor |
| DEV-19 | Nihai tasarım ve açık eksikleri kullanıcıya tek önizleme üzerinden sun; değişiklikleri uygula | DEV-18 | Bekliyor |
| DEV-20 | Yayına hazır paket: kaynak kod, veri/yedek, işletme talimatı, maliyet, geri dönüş; yayın onayı sonrası domain/HTTPS/canlı test | DEV-19 | Bekliyor |

## İşlerin eşzamanlı yürütülmesi

Katalog aktarımı sürerken DEV-02/05 ve DEV-03 küçük doğrulanmış örnekle yürüyebilir. A ve B farklı dosyalarda geliştirilir; veri şeması tek sorumluda tutulur. Çeviri ve içerik denetimi hazır sayfalar üzerinde kademeli ilerler. Çakışan dosyalar aynı anda değiştirilmez. Tam katalog bitmeden tüm katalog bittiği veya tüm diller bitmeden çok dilli teslimin tamamlandığı söylenmez.

## Her çalışmanın güncelleyeceği kayıt

Görev kimliği; başlangıç/bitiş zamanı; yapılan değişiklik; commit/dosya; çalıştırılan test ve sonucu; önizleme; engel; sıradaki görev. Başarısız iş sonraki göreve gizlenerek aktarılmaz. Sonraki çalıştırma kayıt ve güncel depo durumunu okuyarak başlar. İnsan kararı gereken işler ayrılırken bağımsız onaylı işler devam eder.
