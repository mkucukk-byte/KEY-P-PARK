# KEYİF PARK — Teslim kapsamı ve kabul ölçütleri

Güncelleme: 16 Eylül 2026. Bu belge teknik kapsam kaydıdır; çalışan bulut görevinin veya tamamlanmış teslimin kanıtı değildir.

## Hedef

KEYİF PARK adına kurumsal, uluslararası, mobil ve masaüstünde kullanılabilir; gerçek üretici ürünlerini sunan ve proje teklifi toplamaya hazır bir web sitesi teslim etmek. Kullanıcının yazılımcı gibi görev dağıtması beklenmez. Önceden onaylanan işler seri bazında tekrar onaya gönderilmez.

## Kesin kararlar

- Next.js uygulaması; aynı ürün verisini kullanan, gerçekten farklı yerleşim ve keşif deneyimine sahip A — Yeni Nesil ve B — Işıltı Park referanslı tasarımlar.
- Onaylı marka referansı: `references/approved-brand.png`. Beğenilen görsel yön: `references/approved-concept.png`. Bunlar çalışan sayfaya uygulanacak; geçici simge nihai logo yerine kullanılamaz.
- Gerçek ürün, seri, kategori, teknik metin, görsel ve erişilebilir bağlı belgelerin kaynağı IŞILTI PARK. Kaynak bağlantısı, aktarım tarihi ve doğrulama durumu korunur. Hatalı kaynak ölçüsü sessizce düzeltilmez.
- Orijinal görsel dosyaları ayrı saklanır; erişilebilir en yüksek kaynak çözünürlüğü alınır. Web için boyutlandırılmış sürümler üretilir. Yapay büyütme gerçek ürün detayı üretmek için kullanılmaz.
- Diller: TR, EN, RU, ES, PT, AR, DE, IT, RO, BG, AZ, FR. Arapça sağdan sola. Dil seçicinin bulunması tam çeviri teslimi sayılmaz.
- E-ticaret, fiyatla satın alma, ödeme, sipariş ve Shopify kapsam dışı. Proje teklif listesi ve teklif talebi kapsam içinde.
- E-katalog, ürün arama/filtre, teknik detaylar, chatbot, içerik yönetimi ve SEO aşamalı tamamlanacak. Strapi/Contentful ve arama/AI sağlayıcısı mevcut hesaba ve maliyete göre seçilecek; entegrasyon adı yazılması çalışan özellik sayılmaz.
- Referanslar uydurulmaz. Ürün sertifikaları, güvenlik iddiaları, teknik değerler, firma iletişim bilgileri ve geçmiş proje fotoğrafları doğrulanmadan yayımlanmaz.

## Yayına hazır kabul ölçütleri

1. Onaylı marka uygulanmış; A/B masaüstü ve mobil önizlemeleri farklı ve tamamlanmış. Nihai yayın tasarımı kullanıcıya gösterilmiş.
2. Ana sayfa, menü, kategori/seri, arama, ürün detay, teklif, e-katalog ve kurumsal/iletişim sayfaları gerçek rotalarda çalışıyor. Geçersiz ürün adresi doğru 404 döndürüyor.
3. Bulunan katalog envanteri ile içe aktarılan ürünler karşılaştırılmış; eksik ve erişilemeyen her kaynak ayrı listelenmiş. Ürün verisi iki tasarımda ortak.
4. Ürün detayında mevcut teknik değerler, gerçek görseller, kaynak belgeler ve ilgili teklif bağlantısı bulunuyor. Bilinmeyen alanlar değer uydurularak doldurulmuyor.
5. Teklif formu doğrulama, hata ve başarı durumlarıyla gerçek alıcıya teslim ediliyor; kullanıcıya başarı gösterilmeden teslim sonucu doğrulanıyor. Gizlilik metni gerçek veri akışıyla uyumlu.
6. 12 dilde tüm ziyaretçi arayüzü ve yayımlanan içerik kapsamı denetlenmiş; eksik çeviriler raporlanmış. AR yönü, dil değişiminde sayfa bağlamı, hreflang ve dil başına adresler kontrol edilmiş.
7. Chatbot doğrulanmış ürün kaynağından yanıt veriyor; fiyat/teknik bilgi uydurmuyor; hizmet kapalıysa anlaşılır durum gösteriyor. Görsel arama çalışır örneklerle doğrulanmış veya açıkça tamamlanmamış iş olarak kalıyor.
8. Yönetim panelinde ürün/belge düzenleme gösterilmiş; yetki, yedekleme ve geri yükleme yöntemi belgelenmiş.
9. 360/390/768/1440 piksel genişliklerde taşma yok; dokunmatik menü, klavye kullanımı, odak, temel ekran okuyucu etiketleri, form akışı, kırık görseller ve bağlantılar kontrol edilmiş. Tarayıcı emülasyonu gerçek iOS/Android cihaz testi olarak raporlanmıyor.
10. Üretim derlemesi ve kritik gezinme testleri geçiyor; sayfa başlıkları, açıklamalar, sitemap, robots ve görsel yükleme ölçümleri kayıtlı. Önizleme arama motoruna kapalı.
11. Yayın öncesi önizleme, test raporu, açık eksikler, işletme maliyetleri ve yayın/geri dönüş adımları tek teslim kaydında bulunuyor. Kullanıcı yayın onayından sonra alan adı/HTTPS/canlı form doğrulanıyor.

## Onay sınırları

Rutin geliştirme, veri aktarımı, hata düzeltme, test, taslak hazırlama ve önizleme için tekrar onay yok. Kullanıcıya yalnızca somut nihai tasarım kararı, yeni ücretli hizmet/harcama ve halka açık yayın kararı getirilir. Gerekli hesap erişimi ve doğrulanamayan işletme bilgileri tek eksik listesinde toplanır; şifreler sohbetten istenmez.

## Kanıt kuralı

Her tamamlanan iş commit veya dosya, test sonucu ve gerekiyorsa önizleme bağlantısıyla kayıt altına alınır. Kuyruğa alınmış iş tamamlandı sayılmaz. Zamanlayıcı, derleme veya katalog indirme görevi tek başına bağımsız AI kodlama görevi sayılmaz. Canlı durum son kontrol zamanı ve gerçek çalışma bağlantısıyla raporlanır.

