import './globals.css';
export const metadata = { title: 'KEYİF PARK — Birlikte daha güzel bir dünya', description: 'Oyun, hareket ve yaşam alanları. KEYİF PARK tasarım önizlemesi.' };
export default function Layout({children}:{children:React.ReactNode}) { return <html lang="tr"><body>{children}</body></html> }
