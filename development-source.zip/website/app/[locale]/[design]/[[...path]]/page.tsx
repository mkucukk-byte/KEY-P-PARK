import {notFound} from 'next/navigation';
import Site from '../../../../components/Site';
import {locales,products} from '../../../../lib/data';
export default async function Page({params,searchParams}:{searchParams:Promise<{product?:string}>;params:Promise<{locale:string;design:string;path?:string[]}>}){const p=await params;const query=await searchParams;const path=p.path||[];if(!locales.includes(p.locale)||!['a','b'].includes(p.design)||!((path.length===0)||(path.length===1&&['products','catalog','quote'].includes(path[0]))||(path.length===2&&path[0]==='product'&&products.some(x=>x.slug===path[1]))))notFound();return <Site key={p.locale+p.design+path.join("/")+(query.product||"")} selectedProduct={query.product||"general"} locale={p.locale} design={p.design} path={path}/>}

