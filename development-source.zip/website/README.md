# KEYİF PARK — A + B

İlk çalışan Next.js uygulaması. A ve B aynı ürün verisini kullanır.

## Çalıştırma

Node.js 20.9 veya üzeri gereklidir.

```sh
corepack pnpm install --frozen-lockfile
corepack pnpm dev
```

Üretim kontrolü: `corepack pnpm build`, ardından `corepack pnpm start`.

- A: http://localhost:3000/tr/a
- B: http://localhost:3000/tr/b
- Sayfalar: `/products`, `/product/orbit`, `/catalog`, `/quote`
- Dil kodları: tr, en, ru, es, pt, ar, de, it, ro, bg, az

## İçerik ve sınırlar

- Onaylı logo/kimlik dosyaları bu oturumda mevcut değildi. Yazı işareti ve renkler geçicidir.
- Ürünler, kodlar ve SVG çizimler özgün demo içeriktir. Gerçek ürün teknik özellikleri veya sertifikaları temsil edilmez.
- 11 dilde temel menü/ana sayfa sözlüğü ve AR RTL bulunur. Diğer yardımcı metinlerde ve ürün adlarında Türkçe dışındaki diller İngilizceye düşer. Tam çeviri ve editör kontrolü sonraki aşamadır.
- Teklif formu yerel JSON dosyası indirir; e-posta göndermez, veritabanına yazmaz.
- E-katalog giriş sayfası çalışır; gerçek PDF henüz yoktur.
- Strapi, Shopify, Algolia, Dify ve OpenAI bağlantıları yoktur. AI çalışıyormuş izlenimi veren sahte sohbet eklenmemiştir.
- B katalog yaklaşımıdır; Işıltı Park sitesinin tam görsel incelemesi erişim doğrulaması nedeniyle yapılamadı. Kaynak: https://www.isiltiplastik.com/tr/urunlerimiz.php

## Veri mimarisi

`lib/data.ts`: ortak Product tipi, demo ürünler, dil sözlüğü.
`components/Site.tsx`: ortak gezinme, ürün/teklif/katalog sayfaları.
`app/globals.css`: A ve B tasarım kuralları, responsive ve RTL uyumlu mantıksal boşluklar.
`app/[locale]/[design]/[[...path]]/page.tsx`: dil/tasarım ve geçerli ürün rotalarının doğrulaması.

## Sonraki kontrollü aşama

1. Onaylı logo ve kurumsal kimliği uygulama; B referansının görsel doğrulaması.
2. Yetkili gerçek ürün aktarımı ve teknik belge doğrulaması.
3. Tam dil çevirileri, gerçek iOS/Safari ve Android cihaz kontrolleri.
4. Yönetim, ticaret, arama ve AI servislerini ayrı ayrı bağlama.
5. Yayın ortamı ve alan adı yapılandırması.

Bu yerel sunucu bilgisayar kapalıyken çalışmaz. Bulut yayını veya kendiliğinden devam eden geliştirme süreci kurulmamıştır.
